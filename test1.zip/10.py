import json
s1=json.load(open("1.json"))
print(s1)



