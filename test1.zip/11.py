import json
data={"name":"Kuthyar", "city":"Bangalore"}
s1=json.dumps(data)
print(s1)



